<?php
add_action( 'wp_enqueue_scripts', 'enqueue_astra_child' );
function enqueue_astra_child()
{
      wp_enqueue_style('astra-css', './astra/style.css' );
      wp_enqueue_style('astra-child-css', './astra-child/style.css');
      wp_enqueue_script('astra-child-js', './astra-child/js/script.js', array( 'jquery' ), '1.0', true );
}
?>